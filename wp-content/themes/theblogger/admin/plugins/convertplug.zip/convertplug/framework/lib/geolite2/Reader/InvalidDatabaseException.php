<?php
// phpcs:ignoreFile -- this is a third-party lib
namespace CPlus\MaxMind\Db\Reader;

/**
 * This class should be thrown when unexpected data is found in the database.
 */
class InvalidDatabaseException extends \Exception {

}
